import React from 'react';

const about = () =>(
    <p>hello this is one</p>
    );

export default about;