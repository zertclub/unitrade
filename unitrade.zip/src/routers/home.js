import React from 'react';
import 'normalize.css/normalize.css';
import Bootstrap from 'bootstrap/dist/css/bootstrap.css';
import {Button,Grid,Row,Jambotron,Col} from 'react-bootstrap';


const home = (props) =>(

<div>
<Grid>
  <Row>
    <Col lg={2} md={4} sm={8} xs={10} >
      <Image src="/logo.png" rounded />
    </Col>
  </Row>
</Grid>


</div>
    


    );

export default home;
